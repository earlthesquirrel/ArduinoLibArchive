var indexSectionsWithContent =
{
  0: "abcdfgiprsu",
  1: "bd",
  2: "b",
  3: "abcdfgiprsu",
  4: "p",
  5: "b"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "variables",
  5: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Variables",
  5: "Pages"
};

