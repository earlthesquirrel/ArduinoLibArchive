var searchData=
[
  ['interval_35',['interval',['../class_debouncer.html#a930bf3945e698d77b889f6309079857d',1,'Debouncer']]],
  ['ispressed_36',['isPressed',['../class_bounce2_1_1_button.html#a94c31de8109c89d6ee577ed9b14ea676',1,'Bounce2::Button']]]
];
