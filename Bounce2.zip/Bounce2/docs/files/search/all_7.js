var searchData=
[
  ['pin_13',['pin',['../class_bounce.html#a1cb79cb0ba2379cd12cc7c098d97053a',1,'Bounce']]],
  ['pressed_14',['pressed',['../class_bounce2_1_1_button.html#a3fbacfb9a631e03afcfaa5dc39686bad',1,'Bounce2::Button']]],
  ['previousduration_15',['previousDuration',['../class_debouncer.html#a89ab95e7ac24874bb8cb684dc36a98b9',1,'Debouncer']]]
];
