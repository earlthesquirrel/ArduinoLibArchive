Welcome to Tah


You'll need to do two things - First, add this folder to your arduino/hardware folder, and you should be able to select Tah as a board to compile to.

For MAC OSX  or UNIX based OS:

When you insert Tah for first time, it will appear as HID device and a window will pop up asking you to install a driver, Just cancel that window and you are all set to use it. No driver is required for Tah on MAC OSX and any UNIX based Operating system.


For Windows:

When you compile for the first time, you'll need to install the drivers.  It's the
same process you took for installing the Arduino Leonardo drivers, only this time you 
need to point Windows to this folder so it can find the Tah.inf file.


Have fun!!