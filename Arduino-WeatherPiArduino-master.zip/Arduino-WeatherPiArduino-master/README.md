WeatherPiArduino Libraries and Example

Supports SwitchDoc Labs WeatherRack / Argent Data / Sparkfun

Supports ArduinoConnect Control Panel (www.milocreek.com)

Version 1.6
SwitchDocLabs
Documentation for WeatherPiArduino under products on:

http://www.switchdoc.com/

February 13, 2015

Support for all 7 I2C devices supported by WeatherPiArduino

Files include:
	WeatherPiArduino.ino - main file / includes ArduinoConnect Server (www.milocreek.com)
	Local.h - All the ArduinoConnect Control Panel (www.milocreek.com) Code
	

other support files and libraries

To Install:

Copy all of the directories in the libraries folder into your Arduino libraries folder and then restart the Arduino IDE.




