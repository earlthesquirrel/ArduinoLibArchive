Tah Library
============

This is the Arduino library for accessing the Bluetooth LE capability of the
[Tah](http://tah.io) board

### Documentation
You can find the documentation [here](http://docs.tah.io/library/)
### Installing
* You can download the latest source code for our Tah sketches from GitHub
[here](https://github.com/tah-io/Tah_Arduino_Library/archive/master.zip)
* Rename the downloaded archive to Tah.zip
* Do not unzip the downloaded library, leave it as is. In the Arduino IDE, navigate to Sketch > Import Library. At the top of the drop down list, select the option to "Add Library".
* You will be prompted to select the library you would like to add. Navigate to
the .zip file's location and open it.
* Restart the IDE
* Return to the Sketch > Import Library menu. You should now see the library at the bottom of the drop-down menu. It is ready to be used in your sketch. 
