var searchData=
[
  ['enableverbosity_77',['enableVerbosity',['../classaunit_1_1Test.html#a3490d139e963b7308e8a201d430bdb8d',1,'aunit::Test']]],
  ['exclude_78',['exclude',['../classaunit_1_1TestRunner.html#ad55fbb77f52eb2c1a2d45536e8c4afba',1,'aunit::TestRunner::exclude(const char *pattern)'],['../classaunit_1_1TestRunner.html#aacd40834554b476893701d7492d2d550',1,'aunit::TestRunner::exclude(const char *testClass, const char *pattern)']]],
  ['expire_79',['expire',['../classaunit_1_1Test.html#aab89c47bfa768b0dbf9eb18a777ac4bc',1,'aunit::Test']]],
  ['expiretestnow_80',['expireTestNow',['../MetaAssertMacros_8h.html#a0f865d01d2abffc7ba9365ebcdb3eda9',1,'MetaAssertMacros.h']]],
  ['externtest_81',['externTest',['../TestMacros_8h.html#a144a141e11afa7d1071965e962dbfb42',1,'TestMacros.h']]],
  ['externtestf_82',['externTestF',['../TestMacros_8h.html#a411a4acc9c28fd3d2e9e83b63b91e145',1,'TestMacros.h']]],
  ['externtesting_83',['externTesting',['../TestMacros_8h.html#a6f5d7f585ea78b8e7bee81bc655de07e',1,'TestMacros.h']]],
  ['externtestingf_84',['externTestingF',['../TestMacros_8h.html#a00e313531a1972e4ad46c4681b52512a',1,'TestMacros.h']]]
];
