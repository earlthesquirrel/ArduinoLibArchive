 /*

 ThingSpeak Client to Update Channel Feeds
 
 The ThingSpeak Client sketch is designed for the Arduino + Ethernet Shield.
 This sketch updates a channel feed with an analog input reading via the
 ThingSpeak API (http://community.thingspeak.com/documentation/)
 using HTTP POST.
 
 Created: January 25, 2011 by Hans Scharler (http://www.iamshadowlord.com)
 
 Additional Credits: Example sketches from Tom Igoe and David A. Mellis
 
 Converted to Client Library by Earl Baugh
 
*/

#ifndef THINGSPEAKCLIENT_H
#define THINGSPEAKCLIENT_H

#include <SPI.h>
#include <Ethernet.h>

//#define TSDEBUG 

#ifdef TSDEBUG
 #define TSDEBUG_PRINT(x)  Serial.print(x)
 #define TSDEBUG_PRINTLN(x)  Serial.println(x)
#else
 #define TSDEBUG_PRINT(x) //
 #define TSDEBUG_PRINTLN(x) //
#endif
  
#ifndef LOCALMAC  
static uint8_t tsmac[]  = { 0xDE, 0xAD, 0xBE, 0xEF, 0xFE, 0xED };
#else
static uint8_t tsmac[]  = LOCALMAC;
#endif


#ifndef LOCALIP 
static unsigned char tsip[]       	= { 204, 145, 244, 91 };
#else
static unsigned char tsip[]       	= LOCALIP;
#endif


// ThingSpeak Settings
static char* tsserver   			    = "thingspeak.com";
static unsigned char tsserverIp[] 	= { 184,106,153,149 };


class ThingSpeakClient 
{ 	
  public:
	// constructor for webserver object
  	ThingSpeakClient();

  	void sendData( char * writeKey, String fieldData );
  	String getData( char * readAPIKey, long channelNumber, int fieldNumber);

  	EthernetClient client;

};

ThingSpeakClient::ThingSpeakClient()
{ 
  	Serial.println("Initializing the Ethernet interface for ThingSpeak");
 
	if ( Ethernet.begin( tsmac ) == 0 )
	{
   		Ethernet.begin( tsmac, tsip );
   	}
   	
  	Serial.print("Ip Address we got was : ");
  	Serial.println(Ethernet.localIP());
  	
  	// Wait for a sec for network to stabilize.
  	delay(1000);
}


void ThingSpeakClient::sendData( char * writeAPIKey, String fieldData )
{

  TSDEBUG_PRINTLN("Before making connection");
  // if you get a connection, report back via serial:
  if (ThingSpeakClient::client.connect(tsserverIp, 80)) 
  {
  
    ThingSpeakClient::client.print("POST /update.json HTTP/1.1\n");
    TSDEBUG_PRINTLN("POST /update.json \nHTTP/1.1\n");
       
    ThingSpeakClient::client.print("Host: api.thingspeak.com\n");
    TSDEBUG_PRINTLN("Host: api.thingspeak.com\n");
     
    ThingSpeakClient::client.print("Content-Type: application/x-www-form-urlencoded\n");
    TSDEBUG_PRINTLN("Content-Type: application/x-www-form-urlencoded\n"); 
     
    ThingSpeakClient::client.print("Connection: close\n");
    TSDEBUG_PRINT("Connection: close\n");               
                
    ThingSpeakClient::client.print("X-THINGSPEAKAPIKEY: ");
    ThingSpeakClient::client.print(writeAPIKey);
    TSDEBUG_PRINT("X-THINGSPEAKAPIKEY: ");
    TSDEBUG_PRINT(writeAPIKey);
    
	ThingSpeakClient::client.print("\nContent-Length: ");
	ThingSpeakClient::client.print(fieldData.length());
	ThingSpeakClient::client.print("\n\n");
	TSDEBUG_PRINT("\nContent-Length: ");
	TSDEBUG_PRINT(fieldData.length());
    TSDEBUG_PRINTLN("\n\n");

    ThingSpeakClient::client.print(fieldData);
    TSDEBUG_PRINT(fieldData);
     
    delay(1000);
    
   	TSDEBUG_PRINTLN("Starting to receive data back");
    // Check to see if the server sent anything back...
  	while ( ThingSpeakClient::client.available() )
  	{
  			char c = client.read();
    		TSDEBUG_PRINT(c);
  	}
  	
  	TSDEBUG_PRINT("\nDone receiving data back\n");
  	
    // if the server's disconnected, stop the client:
  	if (!ThingSpeakClient::client.connected())
  	{
    	TSDEBUG_PRINT("disconnecting.\n");
    	ThingSpeakClient::client.stop();
  	}
  	  	
	ThingSpeakClient::client.stop();
  } 
  else 
  {
    TSDEBUG_PRINT( "connection failed\n" );
    ThingSpeakClient::client.stop();
    delay(1000);
  }
}

String ThingSpeakClient::getData( char * readAPIKey, long channelNumber, int fieldNumber)
{
  String result = "";
  TSDEBUG_PRINTLN("Before making connection");
  // if you get a connection, report back via serial:
  if (ThingSpeakClient::client.connect(tsserverIp, 80) ) 
  {
  
    ThingSpeakClient::client.print("GET /channels/");
    TSDEBUG_PRINT("GET /channels/");
    ThingSpeakClient::client.print(channelNumber);
    TSDEBUG_PRINT(channelNumber);
    ThingSpeakClient::client.print("/fields/");
    TSDEBUG_PRINT("/fields/");
    ThingSpeakClient::client.print(fieldNumber);
    TSDEBUG_PRINT(fieldNumber);
    ThingSpeakClient::client.print("/last?api_key=");
    TSDEBUG_PRINT("/last?api_key=");
    ThingSpeakClient::client.print(readAPIKey);
    TSDEBUG_PRINT(readAPIKey);
    ThingSpeakClient::client.print("\nHTTP/1.1\n");               
    TSDEBUG_PRINT("\nHTTP/1.1\n");
    ThingSpeakClient::client.print("Host: api.thingspeak.com\n");   
    TSDEBUG_PRINT("Host: api.thingspeak.com\n");            

    TSDEBUG_PRINTLN(readAPIKey);
    ThingSpeakClient::client.print("\n\n");    
    TSDEBUG_PRINTLN("\n\n");

    delay(1000);
    
   	TSDEBUG_PRINTLN("Starting to receive data back\n");
    // Check to see if the server sent anything back...

  	while ( ThingSpeakClient::client.available() )
  	{
  			char c = client.read();
  			result = result + c;
    		TSDEBUG_PRINT(c);
  	}
  	
  	TSDEBUG_PRINT("Result is ");
  	TSDEBUG_PRINTLN(result);
  	
  	TSDEBUG_PRINTLN("Done receiving data back");
  	
    // if the server's disconnected, stop the client:
  	if (!ThingSpeakClient::client.connected())
  	{
    	TSDEBUG_PRINTLN("disconnecting.\n");
    	ThingSpeakClient::client.stop();
  	}
  	  	
	ThingSpeakClient::client.stop();
  } 
  else 
  {
    TSDEBUG_PRINTLN("connection failed\n");
    ThingSpeakClient::client.stop();
    delay(1000);
  }
  return result;
}

#endif // For File Include.