 /*

 Weather Underground Client to Update Channel Feeds
 
 The Client sketch is designed for the Arduino + Ethernet Shield.
 Used the GET protocol described on http://wiki.wunderground.com/index.php/PWS_-_Upload_Protocol
 
 By Earl Baugh
 
*/

#ifndef WUNDERGROUNDCLIENT_H
#define WUNDERGROUNDCLIENT_H

#include <SPI.h>
#include <Ethernet.h>

//#define WUDEBUG

#ifdef WUDEBUG
 #define WUDEBUG_PRINT(x)  Serial.print(x)
 #define WUDEBUG_PRINTLN(x)  Serial.println(x)
#else
 #define WUDEBUG_PRINT(x) //
 #define WUDEBUG_PRINTLN(x) //
#endif
  
#ifndef LOCALMAC  
static uint8_t wumac[]  = { 0xDE, 0xAD, 0xBE, 0xEF, 0xFE, 0xED };
#else
static uint8_t wumac[]  = LOCALMAC;
#endif


#ifndef LOCALIP 
static unsigned char wuip[]       	= { 204, 145, 244, 91 };
#else
static unsigned char wuip[]       	= LOCALIP;
#endif


// WUnderground Settings
static char* wuserver   			    = "weatherstation.wunderground.com";
static unsigned char wuserverIp[] 	= { 38,102,137,157 };


class WUndergroundClient 
{ 	
  public:
	// constructor for webserver object
  	WUndergroundClient();

  	void sendData( char * password, char * stationNumber, 
			String windspeedmph, String windgustmph, 
			String humidity, String temp1f, String temp2f, String temp3f,
			String dailyRain, String baromin, char * softwaretype );

  	EthernetClient client;

};

WUndergroundClient::WUndergroundClient()
{
  	Serial.println("Initializing the Ethernet interface For WUnderground");
 
	if ( Ethernet.begin( wumac ) == 0 )
	{
   		Ethernet.begin( wumac, wuip );
   	}
   	
  	Serial.print("Ip Address we got was : ");
  	Serial.println(Ethernet.localIP());
  	
  	// Wait for a sec for network to stabilize.
  	delay(1000);
}



void WUndergroundClient::sendData( char * password, char * stationNumber, 
			String windspeedmph, String windgustmph, 
			String humidity, String temp1f, String temp2f, String temp3f,
			String dailyRain, String baromin, char * softwaretype )
{
  String result = "";
  // if you get a connection, report back via serial:
  if (WUndergroundClient::client.connect(wuserverIp, 80) == 1) 
  {
   	WUDEBUG_PRINT("Starting to send data\n");

    WUndergroundClient::client.print("GET /weatherstation/updateweatherstation.php?ID=");
    WUndergroundClient::client.print(stationNumber);
    WUndergroundClient::client.print("&PASSWORD=");
    WUndergroundClient::client.print(password);
    WUndergroundClient::client.print("&dateutc=now");
   	WUndergroundClient::client.print("&windspeedmph=");
    WUndergroundClient::client.print(windspeedmph);
    WUndergroundClient::client.print("&windgustmph=");
    WUndergroundClient::client.print(windgustmph);
    WUndergroundClient::client.print("&humidity=");
    WUndergroundClient::client.print(humidity);
    WUndergroundClient::client.print("&tempf=");
    WUndergroundClient::client.print(temp1f);
    WUndergroundClient::client.print("&temp2f=");
    WUndergroundClient::client.print(temp2f);
    WUndergroundClient::client.print("&temp3f=");
    WUndergroundClient::client.print(temp3f);
    WUndergroundClient::client.print("&dailyrain=");
    WUndergroundClient::client.print(dailyRain);
    WUndergroundClient::client.print("&baromin=");
    WUndergroundClient::client.print(baromin);
    WUndergroundClient::client.print("&softwaretype=");
    WUndergroundClient::client.print(softwaretype);
    WUndergroundClient::client.print("\r\n");
//    WUndergroundClient::client.print(" HTTP/1.0\n");    
//    WUndergroundClient::client.print("Host: weatherstation.wunderground.com\n");
//	WUndergroundClient::client.print("Cache-Control: no-cache\n\n");
  
  WUndergroundClient::client.println();

        
    WUDEBUG_PRINT("GET /weatherstation/updateweatherstation.php?ID=");
    WUDEBUG_PRINT(stationNumber);
    WUDEBUG_PRINT("&PASSWORD=");
    WUDEBUG_PRINT(password);
    WUDEBUG_PRINT("&dateutc=now");
   	WUDEBUG_PRINT("&windspeedmph=");
    WUDEBUG_PRINT(windspeedmph);
    WUDEBUG_PRINT("&windgustmph=");
    WUDEBUG_PRINT(windgustmph);
    WUDEBUG_PRINT("&humidity=");
    WUDEBUG_PRINT(humidity);
    WUDEBUG_PRINT("&tempf=");
    WUDEBUG_PRINT(temp1f);
    WUDEBUG_PRINT("&temp2f=");
    WUDEBUG_PRINT(temp2f);
    WUDEBUG_PRINT("&temp3f=");
    WUDEBUG_PRINT(temp3f);
//    WUDEBUG_PRINT("&dailyrain=");
//    WUDEBUG_PRINT(dailyRain);
    WUDEBUG_PRINT("&baromin=");
    WUDEBUG_PRINT(baromin);
    WUDEBUG_PRINT("&softwaretype=");
    WUDEBUG_PRINT(softwaretype);
    WUDEBUG_PRINT("\r\n");
//    WUDEBUG_PRINT(" HTTP/1.0\n");    
//    WUDEBUG_PRINT("Host: weatherstation.wunderground.com\n");
//	WUDEBUG_PRINT("Cache-Control: no-cache\n\n");

   
   	WUDEBUG_PRINT("Starting to receive data back\n");

    WUDEBUG_PRINT("Result is ");
    char c;
    for(;;)
  	{
  		if ( WUndergroundClient::client.available() )
  		{	
  			c = WUndergroundClient::client.read();
  			if (c == -1 )
  			{
  				break;
  			}
  			WUDEBUG_PRINT(c);
  		}	
  		// if the server's disconnected, stop the client:
  		if (!WUndergroundClient::client.connected())
  		{
    		WUDEBUG_PRINT("disconnecting.\n");
    		WUndergroundClient::client.stop();
    		break;
  		}	
  	}
  	WUDEBUG_PRINT("\nDone receiving data back\n");
  } 
  else 
  {
    WUDEBUG_PRINT("connection failed\n");
    WUndergroundClient::client.stop();
    delay(1000);
  }
}

#endif // For File Include.